#ifndef GUI_BACKGROUND_H
#define GUI_BACKGROUND_H

#include <stdint.h>

#define GUI_BACKGROUND_WIDTH       480U
#define GUI_BACKGROUND_HEIGHT      272U
#define GUI_BACKGROUND_CLUT_SIZE   256U

extern const uint8_t gui_background_l8[
    GUI_BACKGROUND_WIDTH * GUI_BACKGROUND_HEIGHT
];

extern const uint32_t gui_background_clut[GUI_BACKGROUND_CLUT_SIZE];

#endif /* GUI_BACKGROUND_H */
